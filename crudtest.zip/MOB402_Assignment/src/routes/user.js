const router = require('express').Router();

const userController = require('../controllers/userController');
router.post('/signup',userController.addUser);
router.post('/login',userController.login);

module.exports = router;
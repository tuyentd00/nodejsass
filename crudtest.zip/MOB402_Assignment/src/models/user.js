const Joi = require('joi');
let mongoose = require('mongoose');

const User = mongoose.model('User',new mongoose.Schema({
    username:{
        type:String,
        require:true,
        minlength:6,
        maxlength:255
    },name: {
        type: String,
        required: true,
        minlength: 5,
        maxlength: 255
    },
    pass: {
        type: String,
        required: true,
        minlength: 5,
        maxlength: 1024
    },repass: {
        type: String,
        required: true,
        minlength: 5,
        maxlength: 1024
    },
}));

function validateUser(user){
    const schema = {
        username:Joi.string().min(6).max(255).required(),
        name:Joi.string().min(6).max(255).required(),
        pass:Joi.string().min(5).max(255).required(),
        repass:Joi.string().min(5).max(255).required()
    };
    return Joi.validate(user,schema);
}
exports.User = User;
exports.validate = validateUser;
let connection = require('../database');
module.exports.addUser = (req, res) => {
    const { fullname, username, pass, repass } = req.body;
    if (fullname == '' || username == '' || pass == '' || repass == '') {
        console.log('khong dc de trong');
    }
    else if (pass != repass) {
        console.log('Pass va repass phai giong')
    }
    else {
            const query = connection.query('insert into user set ?', { fullname, username, pass }, (err, user) => {
                res.redirect('/');
            });
    }
}
module.exports.login = (req, res) => {
    const { username, pass } = req.body
    if (username && pass) {
        const query = connection.query('SELECT * FROM user WHERE username = ? AND pass = ?', [username, pass], (error, results, fields) => {
            if (results.length > 0) {
                res.redirect('/customers')
            }
        })
    } else {
        console.log('Please enter Username and Password!');
    }
}

let connection = require('../database');
// const MongoClient = require('mongodb').MongoClient;
// const uri="mongodb+srv://trinhdtuyen:Hanoi1234@cluster0.cqlyw.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
// const mongo = new MongoClient(uri,{useNewUrlParser:true});
// mongo.connect((err,db)=>{
//     if(err) throw err;
//     console.log('ket noi thanh cong');
//     var dbo = db.db('mob402')

//   })

//1.doc du lieu tu CSDL (select)
module.exports.list = (req,res)=>{
    res.render('login');
};
//2. luu du lieu vao csdl
module.exports.save = (req,res)=>{
    const data = req.body;
    if(req.body.name=='' || req.body.address=='' || req.body.phone==''){
        console.log('khong dc de trong');
    }else{
        
            const query = connection.query('insert into customer set ?',data,(err,customer)=>{
                res.redirect('/customers');
            });
    }
};
//3. edit
module.exports.edit = (req,res)=>{
    const {id} = req.params;

        conn.query("select * from customer WHERE id=?",[id],(err,rows)=>{
            res.render('customers_edit',{data: rows[0]});
        });

};
//4.update
module.exports.update = (req,res)=>{
    const {id} = req.params;
    const newCustomer = req.body;
        connection.query('update customer set ? where id=?',[newCustomer,id],(err,rows)=>{
            res.redirect('/customers');
        });

};
//5.delete
module.exports.delete = (req,res)=>{
    const {id}  = req.params;
    
        connection.query('delete from customer where id=?',[id],(err,rows)=>{
            res.redirect('/customers');
        })

};

module.exports.customer=(req,res)=>{

    let sql = 'select * from customer'

        if (req.query.search) {
            sql += ` where name like '%${req.query.search}%'`
        }
        connection.query(sql,(err,customers)=>{
            res.render('customers',{data: customers});
        });
}
module.exports.signup=(req,res)=>{
    res.render('signup')
}



//export
 //post .body  get .query duonglink co nhieu kieu duong link .params
var mysql=require('mysql');
var connection=mysql.createPool({
 host: 'localhost',
 user: 'root',
 password: '',
 port: 3306,
 database: 'test'
 
});

module.exports=connection;